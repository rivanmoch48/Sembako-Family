SEMBAKO FAMILY v2.7 — PROYEK ANDROID (WebView)

Isi paket ini adalah source project Android Studio yang membungkus file HTML v2.7 menjadi aplikasi Android.
Ini BELUM berupa file APK siap instal, karena lingkungan pembuatan ini tidak memiliki Android SDK/Gradle untuk melakukan build APK.

CARA MEMBUAT APK:
1. Unduh dan ekstrak ZIP ini di komputer.
2. Instal Android Studio dari https://developer.android.com/studio
3. Buka Android Studio > Open, pilih folder SembakoFamilyAndroid.
4. Tunggu Gradle Sync dan instal Android SDK Platform 35 bila diminta.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Setelah selesai, tekan Locate pada notifikasi untuk menemukan app-debug.apk.

CATATAN PENTING:
- Versi 2.7 ini masih menyimpan data secara lokal di perangkat (local storage). Data tidak otomatis sinkron dengan PC/HP lain.
- Jangan hapus data aplikasi atau uninstall sebelum membuat backup dari menu aplikasi jika ada data penting.
- File HTML aplikasi berada di app/src/main/assets/index.html.
